from typing import Optional, List
from fastapi import FastAPI, Query, APIRouter, status
from pydantic import BaseModel, DirectoryPath
import os
import uvicorn
from multiprocessing import Process, Manager
from threading import Thread
from model.errorMessage import Message
from fastapi.responses import JSONResponse

router = APIRouter(tags = ["Count of Files"])

class CountOfFiles(BaseModel):
    numberOfFiles: int

@router.get("/countOfFiles", response_model=CountOfFiles, summary="Count Number of Files",status_code=status.HTTP_202_ACCEPTED, responses={404: {"model": Message}})
def numberOfFiles(path: str = Query(..., example = "C:\Program Files", max_length=150)):
    if not os.path.isdir(path):
        return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"message": f"The path {path} does not exist"})
    else:
        files = next(os.walk(path))[2]
        fileCount = len(files)
        return CountOfFiles(**{"numberOfFiles": fileCount})

