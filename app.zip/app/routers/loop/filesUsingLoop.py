from typing import Optional, List
from fastapi import FastAPI, Query, APIRouter, status
from pydantic import BaseModel, DirectoryPath
import os
import uvicorn
from multiprocessing import Process, Manager
from threading import Thread
from model.errorMessage import Message
from model.models import listOfAllFiles
from fastapi.responses import JSONResponse

router = APIRouter(tags = ["List of Files Using Loop"])

@router.get("/namesOfFiles", response_model=List[listOfAllFiles], summary="Find Names of All Files", status_code=status.HTTP_202_ACCEPTED, responses={404: {"model": Message}})
def nameOfAllFiles(path: List[str] = Query(..., example = ["C:\Program Files","E:\Python"], max_length=150)):
    names = []
    for folder in path:
        if not os.path.isdir(folder):
            return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"message": f"The path {folder} does not exist"})
        files = next(os.walk(folder))[2]
        tempList = {"directoryPath": folder, "listOfFiles":files}
        names.append(listOfAllFiles(**tempList))
    return names

